from fastapi import FastAPI
from pydantic import BaseModel


app = FastAPI()

class User(BaseModel):
    user_id :str
    first_name :str
    last_name : str
    phone_number : str



@app.post("/add_user/")
async def add_user(user: User):
    return "success"







