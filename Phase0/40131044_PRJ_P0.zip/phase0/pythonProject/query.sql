create  table  user(
    user_id char(5)unique ,
    first_name varchar(50) not null ,
    last_name varchar(50),
    phone_number char(11) unique not null ,
    primary key (user_id)
);
create table contacts(
    person_id char(5),
    contact_id char (5),
    primary key (person_id,contact_id),
    foreign key  (person_id) references user(user_id),
    foreign key  (contact_id) references user(user_id)

);
create  table  pv_chat(
    pv_id char(5) not null ,
    user_id1 char(5),
    user_id2 char(5),
    primary key (pv_id),
    foreign key (user_id1) references user(user_id),
    foreign key (user_id2) references user(user_id)

);
create  table group_chat(
    group_id char(5) not null,
    group_name varchar(20) not null,
    primary key (group_id)


);


create  table  memebership(
    group_id char(5)  ,
    member_id char(5) ,
    primary key (group_id,member_id),
    foreign key (group_id) references  group_chat(group_id),
    foreign key (member_id) references user(user_id)
);



create  table  massage(
    msg_id char(5) ,
    pv_id char (5),
    group_id char(5) ,
    s_id char(5) not null ,
    content varchar(100) not null,
    primary key (msg_id),
    foreign key (pv_id) references pv_chat(pv_id),
    foreign key (group_id) references group_chat(group_id),
    foreign key (s_id) references user(user_id)

);
# insert data of user
insert into user(user_id, first_name, last_name, phone_number) values ("1","leila","mohseni","09912611756");
insert into user(user_id, first_name, last_name, phone_number) values ("2","manely","ghasemniya","09912611757");
insert into user(user_id, first_name, last_name, phone_number) values ("3","farzane","javadi","09912611758");
insert into user(user_id, first_name, last_name, phone_number) values ("4","sadegh","rahimi","09912161175");
insert into user(user_id, first_name, last_name, phone_number) values ("5","farhad","dehghani","09912161176");

# insert data of contact
insert  into  contacts(person_id, contact_id)   values ("1","2");
insert  into  contacts(person_id, contact_id)   values ("1","3");
insert  into  contacts(person_id, contact_id)   values ("2","4");
insert  into  contacts(person_id, contact_id)   values ("3","5");
insert  into  contacts(person_id, contact_id)   values ("2","5");
#

# insert data of pv_chat
insert into pv_chat(pv_id, user_id1, user_id2) values("p1","1","2");
insert into pv_chat(pv_id, user_id1, user_id2) values("p2","2","3");
insert into pv_chat(pv_id, user_id1, user_id2) values("p3","3","4");


# insert data of group_chat
insert into group_chat(group_id, group_name) values("g1","mahfal");
insert into group_chat(group_id, group_name) values("g2","CE");
insert into group_chat(group_id, group_name) values("g3","CS");
insert into group_chat(group_id, group_name) values("g4","baharan");

# insert data of memebership
insert  into memebership(group_id, member_id) values ("g1","1");
insert  into memebership(group_id, member_id) values ("g1","2");
insert  into memebership(group_id, member_id) values ("g2","3");
insert  into memebership(group_id, member_id) values ("g3","4");

# insert data of massage
insert into massage(msg_id, pv_id, group_id, s_id, content)  values ("m1","p1",null,"1","salam");
insert into massage(msg_id, pv_id, group_id, s_id, content)  values ("m2",null,"g1","1","khobi");
insert into massage(msg_id, pv_id, group_id, s_id, content)  values ("m3","p1","g1","2","che khabar?");
insert into massage(msg_id, pv_id, group_id, s_id, content)  values ("m4",null,"g3","4","hello");
insert into massage(msg_id, pv_id, group_id, s_id, content)  values ("m5","p2",null,"2","khobi");


