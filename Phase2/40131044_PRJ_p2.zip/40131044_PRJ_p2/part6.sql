
CREATE TABLE db_log (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    operation_type ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    table_name VARCHAR(50) NOT NULL,
    record_id CHAR(5),
	old_values TEXT,
    new_values TEXT
);
DELIMITER //
CREATE TRIGGER trigger_insert_operations AFTER INSERT ON user
FOR EACH ROW
BEGIN
  DECLARE new_values TEXT;
    SET new_values = CONCAT('user_id=', NEW.user_id, ', first_name=', NEW.first_name, ', last_name=', NEW.last_name, ', phone_number=', NEW.phone_number);
    INSERT INTO db_log (operation_type, table_name, record_id, new_values)
    VALUES ('INSERT', 'user', NEW.user_id, new_values);
END;

DELIMITER //
CREATE TRIGGER trigger_update_operations AFTER UPDATE ON user
    FOR EACH ROW
    BEGIN
		DECLARE old_values TEXT;
		DECLARE new_values TEXT;
		SET old_values = CONCAT('user_id=', OLD.user_id, ', first_name=', OLD.first_name, ', last_name=', OLD.last_name, ', phone_number=', OLD.phone_number);
		SET new_values = CONCAT('user_id=', NEW.user_id, ', first_name=', NEW.first_name, ', last_name=', NEW.last_name, ', phone_number=', NEW.phone_number);
		INSERT INTO db_log (operation_type, table_name, record_id, old_values, new_values)
		VALUES ('UPDATE', 'user', NEW.user_id, old_values,new_values);
    END;


DELIMITER //
CREATE TRIGGER trigger_delete_operations AFTER DELETE ON user
FOR EACH ROW
BEGIN
  DECLARE old_values TEXT;
    SET old_values = CONCAT('user_id=', old.user_id, ', first_name=', old.first_name, ', last_name=', old.last_name, ', phone_number=', old.phone_number);
    INSERT INTO db_log (operation_type, table_name, record_id, old_values)
    VALUES ('DELETE', 'user', old.user_id, old_values);
END;
INSERT INTO user (user_id, first_name, last_name, phone_number) VALUES
('@leil', 'Leila', 'Mohseni', '09912611756');
UPDATE user SET phone_number = '091234000' WHERE user_id = '@leil';
delete from user where user_id="@leil";
SELECT * FROM db_log;
















