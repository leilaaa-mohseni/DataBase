#index for user
create index  users_id on user(user_id);

#index for massage
create index message_id on massage(msg_id);
create index message_send_time on massage(system_time);


