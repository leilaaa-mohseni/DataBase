#first view
create  view user_message  as select user.user_id , user.first_name , user.last_name , user.phone_number , massage.content
from user, massage
where massage.s_id=user.user_id;
 select* from  user_message order by user_id;

#second view
CREATE VIEW user_contacts AS
SELECT  u1.first_name AS person_first_name, u1.last_name AS person_last_name, u2.first_name AS contact_first_name, u2.last_name AS contact_last_name
FROM contacts c
JOIN user u1 ON c.person_id = u1.user_id
JOIN user u2 ON c.contact_id = u2.user_id;
select* from user_contacts  order by person_first_name;


#third view
create view user_messege_group as select user.first_name , user.last_name , group_chat.group_name , massage.content
from user , group_chat , memebership ,massage
where user.user_id = memebership.member_id and memebership.group_id = group_chat.group_id
and massage.s_id = user.user_id and massage.group_id = group_chat.group_id;
select * from user_messege_group order by first_name





