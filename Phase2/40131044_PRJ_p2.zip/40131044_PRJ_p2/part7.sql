#first function
DELIMITER $$
CREATE FUNCTION count_messages_between_users(user_id1 CHAR(5), user_id2 CHAR(5))
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE count_message INT;
    SELECT COUNT(*) INTO count_message
    FROM massage, pv_chat
    WHERE pv_chat.user_id1 = user_id1 AND pv_chat.user_id2 = user_id2 AND massage.pv_id = pv_chat.pv_id;
    RETURN count_message;
END $$
select count_messages_between_users("Doroo","jndy")

#second
DELIMITER $$
CREATE PROCEDURE get_active_users_list_in_last_24_hours()
BEGIN
    SELECT DISTINCT s_id
    FROM massage
    WHERE system_time >= NOW() - INTERVAL 24 HOUR;
END $$
DELIMITER ;
CALL get_active_users_list_in_last_24_hours();


#third
DELIMITER $$
CREATE PROCEDURE get_conversation_history(IN user_id1 CHAR(5),IN user_id2 CHAR(5),in limiti int)
BEGIN
    SELECT massage.s_id , massage.content , massage.system_time
    FROM massage , pv_chat
    WHERE massage.pv_id = pv_chat.pv_id  and  pv_chat.user_id1 = user_id1 and  pv_chat.user_id2 = user_id2
    limit limiti;
END $$
DELIMITER ;
CALL get_conversation_history("Doroo","jndy",2);



#fourth
DELIMITER $$
CREATE PROCEDURE search_messages(IN keyword VARCHAR(100))
BEGIN
    SELECT msg_id, content, s_id , system_time
    FROM massage
    WHERE content LIKE CONCAT('%', keyword, '%');
END $$
DELIMITER ;

CALL search_messages('h');



