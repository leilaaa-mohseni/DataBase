CREATE USER 'Arousha2000azad'@'localhost' IDENTIFIED BY 'Arousha_Azad';
GRANT SELECT ON db_j.* TO 'Arousha2000azad'@'localhost';
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'Arousha2000azad'@'localhost';