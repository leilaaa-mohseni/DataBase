
from pydantic import BaseModel

class user(BaseModel):

    user_id : str
    first_name : str
    last_name : str
    phone_number : str
class contacts(BaseModel):
    person_id : str
    contact_id : str
class group_chat(BaseModel):
    group_id: str
    group_name: str

class pv_chat(BaseModel):
    pv_id :str
    user_id1 :str
    user_id2 : str


class memebership(BaseModel):
    group_id : str
    member_id : str


class massage(BaseModel):
    msg_id : str
    pv_id :str
    group_id : str
    s_id : str
    content : str


