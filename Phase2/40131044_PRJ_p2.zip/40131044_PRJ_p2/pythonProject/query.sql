create  table  user(
    user_id char(5)unique ,
    first_name varchar(50) not null ,
    last_name varchar(50),
    phone_number char(11) unique not null ,
    primary key (user_id)
);
create table contacts(
    person_id char(5) ,
    contact_id char (5) ,
    primary key (person_id,contact_id),
    foreign key  (person_id) references user(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
    foreign key  (contact_id) references user(user_id) ON DELETE CASCADE ON UPDATE CASCADE

);
create  table  pv_chat(
    pv_id char(5) not null ,
    user_id1 char(5),
    user_id2 char(5),
    primary key (pv_id),
    foreign key (user_id1) references user(user_id) ON DELETE CASCADE ON UPDATE CASCADE ,
    foreign key (user_id2) references user(user_id) ON DELETE CASCADE ON UPDATE CASCADE

);
create  table group_chat(
    group_id char(5) not null,
    group_name varchar(20) not null,
    owner_id char(5) references user(user_id) unique ,
    primary key (group_id)
);


create  table  memebership(
    group_id char(5)  ,
    member_id char(5) ,
    primary key (group_id,member_id),
    foreign key (group_id) references  group_chat(group_id) ON DELETE CASCADE ON UPDATE CASCADE,
    foreign key (member_id) references user(user_id) ON DELETE CASCADE ON UPDATE CASCADE
);

create  table  massage(
    msg_id char(5) ,
    pv_id char (5),
    group_id char(5) ,
    s_id char(5) not null ,
    content varchar(100) not null,
    time_send timestamp default current_timestamp(),
    primary key (msg_id),
    foreign key (pv_id) references pv_chat(pv_id) ON DELETE CASCADE ON UPDATE CASCADE,
    foreign key (group_id) references group_chat(group_id) ON DELETE CASCADE ON UPDATE CASCADE,
    foreign key (s_id) references user(user_id) ON DELETE CASCADE ON UPDATE CASCADE

);



#Query

# DELETE FROM user
# WHERE user_id  not IN (
#     SELECT member_id FROM memebership
# )


# add this user tom
#{
# "user_id":"11111",
# "first_name":"Tom",
# "last_name":"Kane",
# "phone_number":"+44796268462"
# }
#+080087243744

