from fastapi import FastAPI
from models import user
from models import massage
from models import group_chat
from models import pv_chat
from models import memebership
from models import contacts
import mySqlConnection

app = FastAPI()

@app.post("/add_user/")
async def add_user(this_user: user):
    try:
        mySqlConnection.insert_user(this_user)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "failed"}

@app.post("/add_contact/")
async def add_contact(this_contact: contacts):
    try:
        mySqlConnection.insert_cotact(this_contact)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "failed"}

@app.post("/add_group/")
async def add_group(this_group: group_chat):
    try:
        mySqlConnection.insert_group(this_group)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "failed"}

@app.post("/add_pv_chat/")
async def add_pv(this_pv_chat: pv_chat):
    try:
        mySqlConnection.insert_pv(this_pv_chat)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "failed"}

@app.post("/add_massage/")
async def add_massage(this_massage: massage):
    try:
        mySqlConnection.insert_massage(this_massage)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "failed"}

#
@app.post("/add_membership/")
async def add_membership(this_membership: memebership):
    try:
        mySqlConnection.insert_membership(this_membership)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "failed"}


#read data
@app.get("/read_user/")
async def read_user(user_id):
    user_info = mySqlConnection.select_user(user_id)
    return user_info

@app.get("/read_group/")
async def read_group(group_id):
    group_info = mySqlConnection.select_group(group_id)
    return group_info
@app.get("/read_pv_chat/")
async def read_pv_chat(pv_id):
     pv_info=mySqlConnection.select_pv(pv_id)
     return pv_info
@app.get("/read_massage/")
async def read_massage(msg_id):
    massage_info=mySqlConnection.select_massage(msg_id)
    return massage_info
@app.get("/read_membership/")
async def read_membership(member_id):
    memebership_innfo=mySqlConnection.select_membership(member_id)
    return memebership_innfo
@app.get("/read_contacts/")
async def read_contacts(person_id):
    contacts_info=mySqlConnection.select_conntact(person_id)
    return contacts_info


#update data
@app.patch("/update_user/")
async def update_user(user_id, field_to_update, new_value):
    try:
        mySqlConnection.update_user(user_id, field_to_update, new_value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "User update failed"}
#
@app.patch("/update_group/")
async def update_group(group_id,field_to_update,new_value):
    try:
        await mySqlConnection.update_group(group_id, field_to_update, new_value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "Group update failed"}

@app.patch("/update_massage/")
async def update_massage(msg_id,field_to_update,new_value):
    try:
        await mySqlConnection.update_massage(msg_id,field_to_update,new_value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "massage update failed"}


#
#
# # #delete data
@app.delete("/delete_user/")
async def delete_user(condition:str,value:str):
    try:
        mySqlConnection.delete_user(condition,value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "User deleted failed"}


@app.delete("/delete_contact/")
async def delete_contact(value1:str, value2:str):
    try:
        mySqlConnection.delete_contact(value1,value2)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "contact deleted failed"}

@app.delete("/delete_pv/")
async def delete_pv(value:str):
    try:
        mySqlConnection.delete_pv(value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "pv deleted failed"}


@app.delete("/delete_group/")
async def delete_pv(value:str):
    try:
        mySqlConnection.delete_pv(value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "group deleted failed"}

@app.delete("/delete_membership/")
async def delete_membership(value1:str,value2:str):
    try:
        mySqlConnection.delete_memebership(value1,value2)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "group deleted failed"}


@app.delete("/delete_massage/")
async def delete_massage(value:str):
    try:
        mySqlConnection.delete_massage(value)
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": "massage deleted failed"}


