# first trigger
DELIMITER //
CREATE TRIGGER check_duplicate_phone_number
BEFORE INSERT ON user
FOR EACH ROW
BEGIN
    DECLARE count_phone INT;
    SELECT COUNT(*) INTO count_phone
    FROM user
    WHERE phone_number = NEW.phone_number;
    IF count_phone > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Duplicate phone number is not allowed.';
    END IF;
END //
DELIMITER ;
insert into user (user_id,first_name,last_name,phone_number) values ("nby76","saghar","torabi","3802248034");




# second trigger
DELIMITER //
CREATE TRIGGER check_group_ownership
BEFORE INSERT ON group_chat
FOR EACH ROW
BEGIN
    DECLARE num_owners INT;

    SELECT COUNT(*) INTO num_owners
    FROM group_chat
    WHERE group_id = NEW.group_id;

    IF num_owners >= 2 THEN
        SIGNAL SQLSTATE '45000';
    END IF;
END;
