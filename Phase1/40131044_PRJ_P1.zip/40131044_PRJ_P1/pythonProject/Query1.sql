# هر کاربر در چه گروه هایی عضو است
SELECT user_id,first_name,last_name,phone_number,memebership.group_id from user join memebership on user.user_id = memebership.member_id
union SELECT user_id, first_name, last_name, phone_number, memebership.group_id
FROM user
LEFT JOIN memebership ON user.user_id = memebership.member_id
WHERE memebership.group_id IS NULL OR memebership.group_id = '';

#کاربران یک گروه به ترتیب تعداد پیام های ارسال شده در آن گروه
SELECT user.user_id, user.first_name,user.last_name,user.phone_number, COUNT(massage.msg_id) AS message_count
FROM user
JOIN memebership ON user.user_id = memebership.member_id
JOIN group_chat ON memebership.group_id = group_chat.group_id
LEFT JOIN massage ON user.user_id = massage.s_id AND group_chat.group_id = massage.group_id
WHERE group_chat.group_id = 'g1'
GROUP BY user.user_id, user.first_name
ORDER BY message_count DESC;


#?
#هر گروه چه تعداد کاربر دارد که با یکدیگر چت خصوصی داشته اند.
SELECT m.group_id, g.group_name,
COALESCE(COUNT(DISTINCT CASE WHEN p.user_id1 IS NOT NULL THEN m.member_id END), 0) AS number_of_users_with_private_chat
FROM memebership m
JOIN memebership m2 ON m.group_id = m2.group_id AND m.member_id != m2.member_id
JOIN group_chat g ON m.group_id = g.group_id
LEFT JOIN pv_chat p ON (p.user_id1 = m.member_id AND p.user_id2 = m2.member_id) OR
                      (p.user_id1 = m2.member_id AND p.user_id2 = m.member_id)
GROUP BY m.group_id, g.group_name
ORDER BY m.group_id;

#کاربرانی که در یک روز به خصوص وارد پیام رسان ما شده اند و داخل حداقل دو گروه بیش از یک پیام ارسال کرده اند
select distinct m.s_id from massage as m join user on m.s_id= user.user_id
where date(m.system_time)=2024-06-03 and m.group_id is not null
group by m.s_id having(
select count(*) from ( select group_id from massage where s_id=m.s_id and group_id is not null group by group_id having count(*) >1 ) as supequery )>=2;

#کاربرانی که در یک یا چند گروه با یک کاربر خاص مشترک هستند
SELECT  distinct u.user_id,u.first_name,u.last_name,u.phone_number
FROM user u
JOIN memebership m ON u.user_id = m.member_id
WHERE m.group_id IN (
    SELECT group_id
    FROM memebership
    WHERE member_id = 'mary9'
) AND u.user_id != 'mary9';