import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    port="3307",
    user="root",
    password="password",
    database="db_j"
)
print(mydb)
mycursor = mydb.cursor()


# create tables
def insert_user(thisUser):
    sql = "INSERT INTO user(user_id, first_name, last_name, phone_number) VALUES (%s, %s, %s, %s)"
    user = [thisUser.user_id, thisUser.first_name, thisUser.last_name, thisUser.phone_number]
    mycursor.execute(sql, user)
    mydb.commit()
    return "User added successfully"


def insert_cotact(thisContact):
    sql = "INSERT INTO contacts(person_id, contact_id) VALUES (%s, %s)"
    contact = [thisContact.person_id, thisContact.contact_id]
    mycursor.execute(sql, contact)
    mydb.commit()
    return "Added to contact list"


def insert_group(thisGroup):
    sql = "INSERT INTO group_chat(group_id, group_name) VALUES (%s, %s)"
    group =[thisGroup.group_id, thisGroup.group_name]
    mycursor.execute(sql, group)
    mydb.commit()
    return "The group was created"

def insert_pv(thisPvChat):
        sql = "INSERT INTO pv_chat(pv_id, user_id1, user_id2) VALUES (%s,%s, %s)"
        pv_chat= [thisPvChat.pv_id,thisPvChat.user_id1,thisPvChat.user_id2]
        mycursor.execute(sql, pv_chat)
        mydb.commit()
        return "The pv_chat was created"
#?
def insert_membership(thisMemebership):
        sql = "INSERT INTO memebership(group_id, member_id) VALUES (%s, %s)"
        membership = [thisMemebership.group_id, thisMemebership.member_id]
        mycursor.execute(sql, membership)
        mydb.commit()

def insert_massage(thisMassage):
    if len(thisMassage.pv_id) == 0:
        is_not_pv = True
        check_field=check(thisMassage.s_id,thisMassage.group_id)
        if(check_field):
                sql = "INSERT INTO massage(msg_id, pv_id, group_id, s_id, content) VALUES (%s,%s,%s,%s, %s)"
                if is_not_pv:
                    massage = [thisMassage.msg_id,None,thisMassage.group_id,thisMassage.s_id,thisMassage.content]
                try:
                    mycursor.execute(sql, massage)
                    mydb.commit()
                except Exception as e:
                    return "This massage was sent"
    else:
        sql = "INSERT INTO massage(msg_id, pv_id, group_id, s_id, content) VALUES (%s,%s,%s,%s, %s)"
        massage = [thisMassage.msg_id, thisMassage.pv_id, None, thisMassage.s_id,thisMassage.content]
        try:
            mycursor.execute(sql, massage)
            mydb.commit()
        except Exception as e:
            print(e)


# read data
def select_user(user_id):
    sql = "SELECT * FROM user WHERE user.user_id = %s"
    user1 = (user_id,)
    mycursor.execute(sql,user1)
    result = mycursor.fetchone()
    if result:
         return result
    else:
        return "No one was found with this information"

def select_group(group_id):
    sql = "SELECT * FROM group_chat WHERE group_chat.group_id= %s"
    group1 = (group_id,)
    mycursor.execute(sql, group1)
    result = mycursor.fetchone()
    if result:
        return result
    else:
        return "No such group has been created"

def select_pv(pv_id):
    sql = "SELECT * FROM pv_chat WHERE pv_chat.pv_id= %s"
    pv1 = (pv_id,)
    mycursor.execute(sql, pv1)
    result = mycursor.fetchone()
    if result:
        return result
    else:
        return "No such pv has been created"

def select_massage(massage_id):
    sql = "SELECT * FROM massage WHERE massage.msg_id= %s"
    massage1 = (massage_id,)
    mycursor.execute(sql, massage1)
    result = mycursor.fetchone()
    if result:
        return result
    else:
        return "No message was found with the given id"


def select_conntact(person_id):
    sql = "SELECT * FROM contacts WHERE contacts.person_id= %s"
    user1 = (person_id,)
    mycursor.execute(sql, user1)
    result = mycursor.fetchall()
    if result:
        return result
    else:
        return "No contact was found with the given id"

def select_membership(member_id):
    sql = "SELECT * FROM memebership WHERE memebership.member_id= %s"
    membership1 = (member_id,)
    mycursor.execute(sql, membership1)
    result = mycursor.fetchall()
    if result:
        return result
    else:
        return "No contact was found with the given id"

def update_user(user_id: str, field_to_update: str, new_value: str):
    sql = f"UPDATE user SET {field_to_update} = %s WHERE user_id = %s"
    update_values = (new_value,user_id)
    mycursor.execute(sql, update_values)
    mydb.commit()
    return {"message": "User updated successfully"}


def update_group(group_id:str, field_to_update:str, new_value: str):
    sql = f"UPDATE group_chat SET {field_to_update} = %s WHERE group_id = %s"
    update_values = (new_value, group_id)
    mycursor.execute(sql, update_values)
    mydb.commit()
    return {"message": "group updated successfully"}


def update_massage(msg_id:str, field_to_update:str, new_value: str):
    sql = f"UPDATE massage SET {field_to_update} = %s WHERE msg_id= %s"
    update_values = (new_value, msg_id)
    mycursor.execute(sql, update_values)
    mydb.commit()
    return {"message": "Massage edited successfully"}



# delete data
def delete_user(condition,value):
    if condition == 'user_id':
        sql = "DELETE FROM user WHERE user_id = %s"
    elif condition == 'first_name':
        sql = "DELETE FROM user WHERE  first_name= %s"
    elif condition == 'last_name':
        sql = "DELETE FROM user WHERE  last_name= %s"
    elif condition == 'phone_number':
        sql = "DELETE FROM user WHERE  phone_number= %s"
    val = (value,)
    try:
        mycursor.execute(sql, val)
        mydb.commit()
        return "User deleted successfully"
    except Exception as e:
        print("Error:", e)
        return "Failed to delete user"



def delete_contact(value1,value2):
    sql = "DELETE FROM contacts WHERE contacts.person_id = %s and contacts.contact_id= %s"
    val = (value1,value2,)
    try:
        mycursor.execute(sql, val)
        mydb.commit()
        return "contact deleted successfully"
    except Exception as e:
        print("Error:", e)
        return "Failed to delete"


def delete_pv(value):
    sql = "DELETE FROM pv_chat WHERE pv_chat.pv_id = %s"
    val = (value,)
    try:
        mycursor.execute(sql, val)
        mydb.commit()
        return "pv_chat deleted successfully"
    except Exception as e:
        print("Error:", e)
        return "Failed to delete"

def delete_group(value):
    sql = "DELETE FROM group_chat WHERE group_chat.group_id = %s"
    val = (value,)
    try:
        mycursor.execute(sql, val)
        mydb.commit()
        return "group_chat deleted successfully"
    except Exception as e:
        print("Error:", e)
        return "Failed to delete"

def delete_memebership(value1,value2):
    sql = "DELETE FROM memebership WHERE memebership.group_id = %s and memebership.member_id= %s"
    val = (value1, value2,)
    try:
        mycursor.execute(sql, val)
        mydb.commit()
        return f"User with user_id{value1} left group with group_id{value2}"
    except Exception as e:
        print("Error:", e)
        return "Failed to delete"

def delete_massage(value):
    sql = "DELETE FROM massage WHERE massage.msg_id = %s"
    val = (value,)
    try:
        mycursor.execute(sql, val)
        mydb.commit()
        return "massage deleted successfully"
    except Exception as e:
        print("Error:", e)
        return "Failed to delete"


def check(s_id,group_id):
    sql="SELECT * FROM memebership WHERE memebership.member_id=%s and memebership.group_id=%s"
    list=[s_id,group_id]
    mycursor.execute(sql, list)
    result=mycursor.fetchall()
    if len(result) != 0:
        return True
    else:
        return False


